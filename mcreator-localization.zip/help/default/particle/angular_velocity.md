This parameter controls the initial spinning velocity of the particle.
Negative values mean a counterclockwise rotation.

A value of 0.314 is roughly the same as 1 rotation per second.