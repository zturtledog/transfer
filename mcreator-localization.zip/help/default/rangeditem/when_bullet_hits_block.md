When the bullet hits a block, it will execute the selected procedure.

Passed x, y, and z are the coordinates of the block hit.