Check this parameter if you want it to light a fire when the ranged item hits a block.

Note: this does not catch mobs on fire