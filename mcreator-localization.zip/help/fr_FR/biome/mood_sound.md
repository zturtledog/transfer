Ce paramètre définit le son utilisé dans les grottes (par exemple, Ambient Caves)

NOTE: Disponible seulement pour Minecraft 1.16.x et plus