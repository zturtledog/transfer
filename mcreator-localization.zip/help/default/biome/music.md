This is the music of the biome. This sound will be randomly played.

NOTE: Only available in Minecraft 1.16.x and higher