If checked, water will be placeable inside the block. 

Vanilla examples: Slabs, Stairs, etc.
