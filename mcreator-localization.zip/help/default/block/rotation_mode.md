* **No rotation:** Fixed block orientation.
* **Y-axis rotation (S/W/N/E):** Rotates only the sides based on the way the player is facing.
* **D/U/N/S/W/E rotation:** Rotates all sides based on the way the player is facing.
* **Y-axis rotation (S/W/N/E):** Rotates only the sides based on the block face the block is clicked on.
* **D/U/N/S/W/E rotation:** Rotates all sides based on the block face the block is clicked on.
* **Log rotation (X/Y/Z):** Rotates the block like vanilla logs.