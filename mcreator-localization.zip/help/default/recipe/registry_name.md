The recipe ID of your recipe (For example: diamond_block). 

If you want to override a vanilla recipe, 
you have to enter the same name as the vanilla registry name of the given recipe in this field.