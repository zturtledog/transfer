The player will need to, at least, have this permission level to execute the command. 

You can disable the permission requirement too. 
In this case, the command will work even if the cheats are turned off in a given world.

1 is the most basic permission level, and 4 is the highest (server OP level). 

Check [this page](https://mcreator.net/wiki/command-permission-levels) to see which command can be executed with each permission level.