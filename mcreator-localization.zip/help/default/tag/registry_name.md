This is the registry name of your tag.

The text you write in this field is the text you will have to write to be able to use your tag.

When extending vanilla tag groups, use appropriate vanilla tag names here and use minecraft namespace.