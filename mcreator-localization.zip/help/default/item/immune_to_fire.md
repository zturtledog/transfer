This parameter controls if the item is immune to fire, like Netherite stuff.

NOTE: Only available in Minecraft 1.16.x and higher