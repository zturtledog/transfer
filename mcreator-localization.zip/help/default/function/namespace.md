* **Mod:** Is used for your mod only. (Call such a function as your_mod_id:function_name)

* **Minecraft:** Is used with some Minecraft options (Call such a function as minecraft:function_name)