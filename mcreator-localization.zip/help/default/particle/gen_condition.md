The condition type to spawn particles.

* Always: The particles will spawn without restrictions. They will always spawn.
* Global logic variable: this variable will control particle spawning