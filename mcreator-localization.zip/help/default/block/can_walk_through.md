If this parameter is checked, the player will be able to walk through it, like tall grass and vines, if you check it.

Block will have bounding box, but it will not be collidable.