Utilisez ce paramètre pour avoir des Ruines Océaniques dans votre biome.
* NONE: Aucune Ruine Océanique ne sera générée.
* COLD: Les Ruines Océaniques faites de pierre se génèreront.
* WARM: Les Ruines Océaniques faites de grès peuvent se génèrent.