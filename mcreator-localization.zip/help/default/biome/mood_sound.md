The ambient sound is the sound used for caves (e.g. Ambient Caves)

NOTE: Only available in Minecraft 1.16.x and higher