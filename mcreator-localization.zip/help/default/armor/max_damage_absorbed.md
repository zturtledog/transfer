This parameter defines armor durability and is effectively applied as:

* helmet: max_damage_absorbed * 13
* chestplate: max_damage_absorbed * 15
* leggings: max_damage_absorbed * 16
* boots:  max_damage_absorbed * 11

Vanilla armor uses the following factors:

* Leather armor: 5
* Chainmail armor: 15
* Gold armor: 7
* Diamond armor: 33
* Netherite armor: 37