Select the color your block will apply to the beacon beam (like the red glass, orange glass, etc).

Leave to DEFAULT to keep vanilla handling (no color change).