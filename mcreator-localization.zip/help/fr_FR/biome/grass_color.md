Ce paramètre contrôle la couleur de l'herbe dans ce biome.

Ce paramètre modifie également la couleur des autres plantes (feuillage).