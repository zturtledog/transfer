These numbers define how well the damage to the entity
will be reduced by a given armor part.