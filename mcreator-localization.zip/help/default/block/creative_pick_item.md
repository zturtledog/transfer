This determines what item is selected when you "pick" (middle-click with mouse) the block. 
If empty, the creative pick item is the block itself.