La texture de la couche d'armure sont les textures affichées sur le joueur lorsqu'il a l'armure sur lui.
