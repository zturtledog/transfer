Ce paramètre contrôle le bloc utilisé pour les feuilles au cas où des arbres personnalisés seraient sélectionnés
