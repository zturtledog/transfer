The procedure is executed each time the structure is generated in the world.

Keep in mind some procedure blocks might not work properly in this trigger during early world generation.