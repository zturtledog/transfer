This parameter controls certain aspects of the dimension in relation to weather,
compass function and creature spawning.