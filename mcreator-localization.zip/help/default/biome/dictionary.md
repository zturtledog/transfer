Describe your biome using tags here. These tags might be used by other mods for biome compatiblity and
parameters such as spawning properties.