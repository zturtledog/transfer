This parameter controls the speed of entities on this block.

Default value used by most of the blocks is 1.0.
The soul sand and honey block speed factor is 0.4.