Lorsqu'une entité a équipé le casque, la procédure sera exécutée à chaque tick.

L'entité passée est l'entité portant l'armure, la pile d'objets transmise est la pile d'objets de l'armure.
