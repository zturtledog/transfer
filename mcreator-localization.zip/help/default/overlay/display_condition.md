This procedure specifies if the overlay should be shown.

When the procedure returns true, the overlay will be shown on the screen.