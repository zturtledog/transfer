**Check this box if your block has transparency** - 
Leave unchecked for a solid block, check it if your block is similar to leaves, glass, iron bars, etc.

Transparency types:

* **Solid:** No transparency (similar to dirt, stone, etc.)
* **Cutout:** Transparent without mipmapping (similar to glass)
* **Cutout mipped:** Like Cutout, but with mipmapping
* **Translucent:** Partially transparent and the most resource heavy option (similar to ice)