Écrit un message dans le chat lorsque le joueur termine l'avancement.
