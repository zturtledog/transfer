List of blocks the plant can be placed on.

NOTE: Overrides the plant type placement condition.