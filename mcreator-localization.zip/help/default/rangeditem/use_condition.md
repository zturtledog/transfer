This procedure will be called before the ranged item fires to check if the return value of the
selected procedure is true.

Keep "(always)" to disable any additional conditions. Ammo checks still apply in this case.