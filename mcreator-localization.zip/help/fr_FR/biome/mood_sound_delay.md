Cette valeur définit le temps, en ticks, avant que le son ne soit joué (boucle).

NOTE: Disponible seulement pour Minecraft 1.16.x et plus