If you have enabled "Does item stay in crafting grid when crafted?", 
you can enable this option to damage the item instead of simply keeping it in the crafting grid.