La robustesse est une valeur qui augmentera la protection de l'armure.

L'armure de diamant a une ténacité de 2,0 (pour un total de 8,0)
et l'armure Netherite a une ténacité de 3,0 (pour un total de 12,0).
