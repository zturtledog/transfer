Triggers a procedure randomly.

This trigger is triggered on client-side only so no real world modifications except for 
playing sounds and placing particles should be done from here.