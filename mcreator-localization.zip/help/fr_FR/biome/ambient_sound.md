Le son ambiant est constamment joué dans le biome.

NOTE: Disponible seulement pour Minecraft 1.16.x et plus