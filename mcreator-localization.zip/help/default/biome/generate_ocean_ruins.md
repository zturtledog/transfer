Select this setting to have Ocean Ruins in your biome.
* NONE: No Ocean ruins will be generated.
* COLD: Ocean Ruins made of stone will be generated
* WARM: Ocean Ruins made of sandstone will be generated