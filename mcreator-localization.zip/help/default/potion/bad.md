Check this parameter in case if your effect is bad for the player. 

Example: the Poison or the Instant Damage.