Check this option to change your plant in a Tile entity. 

You will be able to store data (like NBT Tags) inside your plant when this is enabled.

Do not enable this option unless really needed for performance reasons.