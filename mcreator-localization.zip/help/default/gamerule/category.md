This is the GameRule's category. It's used for the classification of the GameRules depending on what they do.

NOTE: Only available in Minecraft 1.16.x and higher