Name in GUI is the name of the mod element
as shown in in-game menus, item tooltips and other
places where visual name display is possible.