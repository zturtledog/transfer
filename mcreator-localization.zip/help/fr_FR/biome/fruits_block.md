Ce paramètre contrôle le bloc utilisé pour les fruits comme les fèves de cacao avec les arbres de la jungle au cas où les arbres personnalisés sont activés.

Sélectionnez le bloc d'air pour désactiver les fruits des arbres.