Select the number of slots your GUI/inventory has. Don't forget to add 1 to the biggest slot ID.

If the block is bound to GUI, set this value to `the biggest slot ID in the GUI + 1`