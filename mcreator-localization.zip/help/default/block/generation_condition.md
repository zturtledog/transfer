To add more conditions to the generator of this block, add your procedure with return value here.

This condition will be used alongside with conditions such as generation biomes and replacement blocks.

Keep in mind some procedure blocks might not work properly in this trigger during early world generation.