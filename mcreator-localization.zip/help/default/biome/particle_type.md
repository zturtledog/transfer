The particle to spawn in this biome.

NOTE: Only available in Minecraft 1.16.x and higher