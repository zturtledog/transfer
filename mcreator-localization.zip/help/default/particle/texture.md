If texture is a tiled texture (multiple textures in a vertical strip),
the texture will be randomly selected from one of the possible tiles in the strip.

When animated texture parameter is enabled, particle will be animated
in the sequence of texture tiles.