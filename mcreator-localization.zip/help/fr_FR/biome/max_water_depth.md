Ce paramètre contrôle de combien de blocs le tronc de l'arbre personnalisé peut être immergé.

NOTE: Disponible seulement pour Minecraft 1.16.x et plus