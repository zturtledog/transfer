Additions sound played in the biome.

NOTE: Only available in Minecraft 1.16.x and higher