Triggers a procedure when the entity walks on the block. 

It won't be called if the entity is sneaking.