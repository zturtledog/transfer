This parameter controls how much external speed parameter is taken into the account
when spawning the particle. When set to 0, particle will not move and only fall, in case
the gravity of the particle is larger than 0.