La probabilité de faire apparaître une particule.

Note: Cette valeur est ensuite divisé par 100 dans le code. La valeur initiale (que vous écrivez) peut contenir des virgules.