This parameter controls the icon displayed inside the player's inventory when the potion is active.
