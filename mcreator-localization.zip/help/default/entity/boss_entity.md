If checked your entity will be boss. 

Color parameter controls the color of the boss bar, similar with the bar style.