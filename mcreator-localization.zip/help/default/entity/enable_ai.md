If checked, this will activate the AI tasks for the entity.

AI tasks defined in the AI task builder will have no effect unless this is enabled.

Unless you are doing some sort of misc entity, you want this to leave enabled.