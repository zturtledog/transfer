This option applies a tint to the block based on biome colors, similar to grass, leaves, and water. 
For best results, the tinted faces should use a grayscale texture.

NOTE: The fog tint type is only available in Minecraft 1.16.x and higher, and defaults to water fog in older versions.
