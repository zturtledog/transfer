Votre biome apparaîtra toujours à proximité du biome sélectionné (il sera utilisé pour les frontières et les transitions du biome).

Exemple: l'océan profond apparaît toujours près du biome océan.