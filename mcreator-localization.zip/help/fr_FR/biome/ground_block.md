Ce paramètre contrôle le bloc sur la couche supérieure du biome.

Généralement, l'herbe vanilla ou personnalisée est utilisée ici pour la plupart des biomes.