Allows mob to have equipment if the mob model supports this.

From left to right the slots represent the right hand, then the left, then the head, 
chestplate, leggings, and boots.