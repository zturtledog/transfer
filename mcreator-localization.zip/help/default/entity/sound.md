The living sound is the ambient sound that the entity will play randomly. 

Leave blank to deactivate its ambient sound.