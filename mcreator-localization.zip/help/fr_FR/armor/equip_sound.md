Le son lorsque le joueur équipe une pièce de l'armure.
