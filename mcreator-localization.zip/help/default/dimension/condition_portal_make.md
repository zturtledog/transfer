If condition is specified, the player needs to pass it in order to build a portal to this dimension.
Itemstack dependency is the item used for the portal activation.