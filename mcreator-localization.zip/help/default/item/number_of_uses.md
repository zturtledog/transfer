This parameter controls the durability of the item (how many times the item can be used).

Set this value to 0 to disable use count mechanic on the given item.

Vanilla values for the reference:

* Gold: 32 uses:
* Wood: 59 uses.
* Stone: 131 uses.
* Iron: 250 uses.
* Diamond: 1561 uses.
* Netherite: 2031 uses.
* Fishing rod: 64 uses.
* Flint and steel: 64 uses.
* Carrot on a stick: 25 uses.
* Shears: 238 uses.
* Trident 250 uses.
* Crossbow: 326 uses.
* Shield: 336 uses.
* Bow: 384 uses.
* Elytra: 432 uses.