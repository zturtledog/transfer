This parameter controls the jump height of entities

Default value used by most of the blocks is 1.0.
The honey block jump factor is 0.5.