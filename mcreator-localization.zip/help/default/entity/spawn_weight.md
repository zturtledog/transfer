This parameter controls the priority that the mob has over others when the game is choosing what mob to spawn. 

A higher weight means more mob spawns in the game will create this mob. 
Make this lower for animals, compared to monsters.

Spawning weight system is in-depth explained [here](https://mcreator.net/wiki/mob-spawning-parameters)