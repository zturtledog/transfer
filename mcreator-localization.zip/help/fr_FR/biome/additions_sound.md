Sons additionnels joués dans le biome.

NOTE: Disponible seulement pour Minecraft 1.16.x et plus