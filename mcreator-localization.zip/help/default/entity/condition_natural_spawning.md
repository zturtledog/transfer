To spawn your entity like the vanilla ones, you don't need to change this option. 

However, if you want to have custom spawning conditions, you need to create a new condition procedure.