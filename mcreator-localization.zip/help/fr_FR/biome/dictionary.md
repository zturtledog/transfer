Décrivez votre biome à l'aide de tags ici. Ces tags peuvent être utilisées par d'autres mods pour la compatibilité du biome et
les paramètres tels que les propriétés d'apparition.