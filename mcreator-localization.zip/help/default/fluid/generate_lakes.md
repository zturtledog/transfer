Select dimension(s) where you want to have lakes with your fluid. 

Leave it blank to deactivate lake spawning of this fluid.