* **Items:** use this to group multiple items together for recipes, procedures, ... 
  Item tags replace the old ore dictionary system
* **Blocks:** only use the block type if you are targeting a block and not its item (_these tags can not be used in recipes_)
* **Entities:** use this tag type to group multiple entities together for a same purpose.
* **Functions:** this tag type is used for tagging functions into groups. 
One such group is called "tick" from the "minecraft" namespace. 
Functions tagged under the "tick" namespace will be executed each game tick.