This parameter controls the underground block below the ground block layer.

Generally, vanilla or custom dirt is used here for most biomes.

This block should be tagged in <b>forge:dirt</b> Blocks tags 
for Forge mods for plants and trees to spawn properly in the biome.