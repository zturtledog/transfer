This parameter controls how many times per chunk plant patch will be generated.

Plants aren't generated individually, but in patches. 

For example, setting this value to 1 does NOT mean there's only one plant in each chunk; 
instead, each chunk will have (at most) one cluster of these plants. 

Because of this, setting this value to a low amount (4 or less) is enough for most purposes.