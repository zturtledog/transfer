Key binding category is category shown in controls section of Minecraft settings.

All keybindings belonging to the same category should have the same category key.

To actually set category name, go to **Workspace -> Localization -> 
Add localization entry** and use _key.category.&lt;your key&gt;_ for the
entry name and then set the value to desired category name.