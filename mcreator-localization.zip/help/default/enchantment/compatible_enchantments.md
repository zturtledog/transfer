If your enchantment can only be combined with specific enchantments, 
you need to select them in this property. 

Leave empty to allow combining with any enchantment.