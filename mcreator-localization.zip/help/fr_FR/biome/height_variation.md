Ce paramètre contrôle la variation de hauteur de ce biome.

Des valeurs plus basses rendront ce biome plus uniforme et plat, tandis que de grandes valeurs rendront ce biome
très dynamique en terrain.