This is the GameRule's type. You must select the best type depending on your plan(s)
* Number means the GameRule can only be modified to be a number (integer)
* Logic means the GameRule can only be a boolean (true or false)