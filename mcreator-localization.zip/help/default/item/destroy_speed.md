Destroy speed parameter controls how fast this item destroys the blocks.

Typical values:
* **1** - normal item
* **1.5** sword
* **2>** harvesting tool