The procedure will be executed when a player leaves the dimension.
