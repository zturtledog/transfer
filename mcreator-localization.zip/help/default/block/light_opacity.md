This property makes the block allow or not allow the light to pass through, 
126 makes it semi-transparent (only in some Minecraft versions), 255 will block all light (default value), 
and 0 will allow all light through.