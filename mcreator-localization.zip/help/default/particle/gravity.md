This parameter specifies particle falling speed.
Negative values will make this particle fly up to the sky.