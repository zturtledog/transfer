Ce paramètre définit la durabilité de l'armure et est effectivement appliqué comme:

* casque: dégâts_maximum_absorbés * 13
* plastron: dégâts_maximum_absorbés * 15
* jambières: dégâts_maximum_absorbés * 16
* bottes: dégâts_maximum_absorbés * 11

L'armure vanilla utilise les facteurs suivants:

* Armure en cuir: 5
* Armure de cotte de mailles: 15
* Armure d'or: 7
* Armure de diamant: 33
* Armure de netherite: 37