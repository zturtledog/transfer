To add more conditions to the placement of your plant, despite the block it has to be on, 
add your procedure with return value here.

NOTE: Overrides the plant type placement condition and extends "can be placed on" blocks list with this additional condition. 
If "can be placed on" blocks list is empty, this procedure is used as the main placing/growth condition.