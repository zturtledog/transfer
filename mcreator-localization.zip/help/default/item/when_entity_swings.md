Triggers a procedure when the entity swings the item in air. 

For example, if you right click on your item in air, the procedure will be executed.