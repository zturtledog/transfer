This parameter controls how many blocks the trunk of the custom tree can have in the water.

NOTE: Only available in Minecraft 1.16.x and higher