Glow texture is additional optional texture layer on the mob.

This texture layer should have the same size and layout as the standard mob texture.

Glow texture will be used to define mob glowing layer. More bright texture areas will
result in these parts of the mob to glow more.

If you don't need glow layer, keep this at default value (empty).