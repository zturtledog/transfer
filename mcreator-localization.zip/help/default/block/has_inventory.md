This parameter will give an inventory to your block. The block will be a tile entity.

This parameter enables features such as:
* NBT tags on block
* Inventory for item storage of block
* Comparator interaction

These features will not work without this parameter checked.