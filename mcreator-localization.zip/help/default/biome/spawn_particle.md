Check this parameter to enable the spawn of ambient particles in the biome.

NOTE: Only available in Minecraft 1.16.x and higher