Sets the movement speed of the mob.
Most normal mobs move at the speed around 0.25, while faster ones such as spiders and wolves move at 0.3.