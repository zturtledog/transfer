The probability to spawn particles.

Note: This value is divided by 100 in the code.